"""
Jasmine Zeng
CS 340: Client/Server Development
Professor Jeff Sanford

Module 5 
5-1 Project One
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # Connection Variables
        # USER = 'aacuser'
        # PASS = 'CS340'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31128
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Connection successful.")

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary    
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty.")

# Create method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            data = self.database.animals.find(data, {"_id": False})
        else:
            data = self.database.animals.find({}, {"_id": False})
        return data
    
# Create method to implement the U in CRUD.
    def update(self, initialData, changedData):
        if initialData is not None:
            if self.database.animals.count_documents(initialData, limit = 1) != 0:
                update_result = self.database.animals.update_many(initialData, {"$set": changedData})
                result = update_result.raw_result
            else:
                result = "Document could not be found."
            return result
        else:
            raise Exception("Nothing to update, because data parameter is empty.")

# Create method to implement the D in CRUD.
    def delete(self, remove):
        if remove is not None:
            if self.database.animals.count_documents(remove, limit = 1) != 0:
                delete_result = self.database.animals.delete_many(remove)
                result = delete_result.raw_result
            else:
                result = "Document could not be found."
            return result
        else:
            raise Exception("Nothing to update, because data parameter is empty.")